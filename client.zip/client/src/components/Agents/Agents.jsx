import React from "react";

function Agents() {
  return (
    <div>
      <div>Agents</div>
    </div>
  );
}

export default Agents;
